public class SavingsAccount extends BankAccount {



    public int getAccountNumber() {
        return accountNumber;
    }

    public void setAccountNumber(int accountNumber) {
        this.accountNumber = accountNumber;
    }

    public StringBuilder getAccountHolderName() {
        return accountHolderName;
    }

    public void setAccountHolderName(StringBuilder accountHolderName) {
        this.accountHolderName = accountHolderName;
    }

    public StringBuffer getAccountType() {
        return accountType;
    }

    public void setAccountType(StringBuffer accountType) {
        this.accountType = accountType;
    }



}
