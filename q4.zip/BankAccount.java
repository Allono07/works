abstract class BankAccount {
   protected int accountNumber;
   protected StringBuilder accountHolderName;
    protected StringBuffer accountType;


}
