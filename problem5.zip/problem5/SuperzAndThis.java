public class SuperzAndThis {
    public static void main(String[] args) {
        Dog dog = new Dog("Buddy", "bowww");
        dog.display();
    }
}