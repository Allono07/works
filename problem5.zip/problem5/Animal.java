class Animal {
    String name;

    Animal(String name) {
        this.name = name;
    }

    void show() {
        System.out.println("Name: " + name);
    }
}