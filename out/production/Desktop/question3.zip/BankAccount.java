abstract class BankAccount {
   protected int accountNumber;
   protected String accountHolderName;
    protected String accountType;


}
